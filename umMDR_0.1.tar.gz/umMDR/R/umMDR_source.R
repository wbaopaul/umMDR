##=======================================================================##
##  This program is written by Wenbao yu for implementing
##  unified MDR, which has the following two step
## 1. assign high/low (S) for each cell
## 2. modeling:  use glm to test association between phenotype and S
## key idea: assume non-central chisquare null for testing association
##=======================================================================##

## list all functions ####


## calculate fist PC score
#' @import compiler MASS glmnet
fpc <- function(pys){
  pys = scale(pys, center = TRUE, scale = FALSE)
  covm = cov(pys)
  eigens = eigen(covm)
  P = eigens$vectors
  AS = pys %*% P[, 1]  ## first PC scores
  return(AS)
}
fpc <- cmpfun(fpc)


## ridge regression given lambda
## note that only the result of the last column of X is returned
#' @import compiler MASS glmnet
ridge_glambda <- function(X, Y, fam, lbd){

  n = nrow(X)
  ff = cbind(rep(1, n), X)
  p = ncol(X)
  # calculate covariance for beta
  if(fam == 'binomial'){
    ## use glmnet
    mod = glmnet(x = X, y = Y, standardize = FALSE,
                 family = fam, alpha = 0, lambda = 2 * lbd)

    beta = as.numeric(coef(mod))
    xx = ff %*% beta
    pp = exp(xx)/(1 + exp(xx))
    ww = diag(as.vector(pp * (1 - pp)))
    temp1 = t(ff) %*% ww %*% ff
    temp2 = solve(temp1 + 2 * lbd * diag(1, ncol(temp1)))
    varbeta = temp2 %*% temp1 %*% temp2
  }else{

    mod = lm.ridge(Y ~ X, lambda = lbd)
    beta = coef(mod)

    temp = solve(t(ff) %*% ff + lbd * diag(ncol(ff)))
    #beta = temp%*% t(ff) %*% Y

    xx = ff %*% beta
    varbeta = temp %*% t(ff) %*% ff %*% temp
    sigma2 = crossprod(Y - xx, Y - xx)/(n- length(beta))
    varbeta = varbeta * as.vector(sigma2)
  }
  wstat = beta[p+1]/sqrt(varbeta[p+1, p+1])
  return(list("wstat" = wstat, "beta" = beta[p+1], "vbeta" = (varbeta[p+1, p+1])))
}
ridge_glambda = cmpfun(ridge_glambda)



## ridge regression for linear and logistic regression, find lambda by cv
#' @import compiler MASS glmnet
ridge_cv <- function(X, Y, fam){

  trainfun <- ifelse(fam == 'binomial', 'auc', 'deviance')
  ## use glmnet to select lambda, but just in case return error
  tryinf <- try(mod <- cv.glmnet(x = X, y = Y, standardize = FALSE,
                       type.measure = trainfun, family = fam, alpha = 0, nfolds = 5), silent = TRUE)
  if('try-error' %in% class(tryinf)){
    lbd = 0.5
    if(fam == 'gaussian') {
      lbds = seq(0,1000,len = 100)
      lbd = lbds[which.min(lm.ridge(phe ~ xx + labels , lambda = lbds)$GCV)]
    }
  }else{
    lbd = mod$lambda.min/2
  }

  res = ridge_glambda(X, Y, fam, lbd)

  return(list('beta' = res$beta, 'vbeta' = res$vbeta, 'lbd' = lbd))
}
ridge_cv = cmpfun(ridge_cv)



## classification step, assign high/low for each cell and test
#' @import compiler MASS glmnet
class_HL <- function(snp.dat, SS, classm = 'mean'){
  snp.dat = as.matrix(snp.dat)

  # remove missing values
  fids = which(complete.cases(snp.dat))
  snp.dat = as.matrix(snp.dat[fids, ])

  k = ncol(snp.dat)
  n = nrow(snp.dat)

  # split completed data into cells
  tlist = vector('list', k)
  for(i in 1:k) tlist[[i]] = snp.dat[, i]
  cells = split(data.frame(cbind(fids, snp.dat)), tlist)

  # delete NULL cells
  obs.cell = sapply(cells, function(x) nrow(x))
  cell.null = which(obs.cell == 0)
  if(length(cell.null) > 0 ) cells = cells[-cell.null]

  ncells = length(cells)
  high.ids  = NULL
  weights = rep(1, n)   ## weights defined as the mean of Y in each cell

  # classify each cell into H/L by various methods
  if(classm == 'mean' || classm == 'fpc'){
    # use mean to define H/L, corresponding to quatitative trait
    sbar = mean(SS)
    for(i in 1:ncells){
      temp.ids = cells[[i]][, 1]
      if(length(temp.ids) == 0) next
      mSS = mean(SS[temp.ids])
      weights[temp.ids] = (length(temp.ids))
      if (mSS >= sbar){
        high.ids = c(high.ids, temp.ids)
      }
    }
  }

  if(classm == 'obs-ratio'){
    # use the ratio of the number of cases to the number of obs,
    # corresponding to binary trait
    sbar = sum(SS)/n
    for(i in 1:ncells){
      temp.ids = cells[[i]][, 1]
      if(length(temp.ids) == 0) next
      temp.ratio = sum(SS[temp.ids])/length(temp.ids)
      weights[temp.ids] = 1/(max(temp.ratio, 1-temp.ratio))
      if (temp.ratio >= sbar){
        high.ids = c(high.ids, temp.ids)
      }
    }
  }

  low.ids = setdiff(fids, high.ids)

  # labels indicate high/low
  labels = rep(NA, n)
  labels[high.ids] = 1
  labels[low.ids] = 0

  # note that labels are NA, corresponding the obs that having NA for SNP
  return(list('labels' = labels, 'weights' = weights))
}
class_HL <- cmpfun(class_HL)


## estimat non-center parameter of the null distribution due to classification
#' @import compiler MASS glmnet
est_nullcenter <- function(phe, cova, snp.pair, classm = 'mean', lbd = 0, nperm = 10){
  if (exists(".Random.seed", .GlobalEnv))
    oldseed <- .GlobalEnv$.Random.seed
  else
    oldseed <- NULL

  set.seed(12345)
  n = nrow(phe)
  centers = rep(0, nperm)
  coefs = rep(0, nperm)
  fam = ifelse(classm == 'obs-ratio', 'binomial', 'gaussian')
  for(i in 1:nperm){
    perm.phe = phe[sample(1:n, n)]
    res = class_HL(snp.pair, perm.phe, classm)
    labels = res$labels
    xx = cbind(cova, labels)
    if(lbd == 0){
      sumstat = coef(summary(glm(perm.phe ~ xx, family = fam)))
      centers[i] = sumstat[nrow(sumstat), 3]
      coefs[i] = sumstat[nrow(sumstat), 1]
    }else{
      ## use ridge regression
      tmp = ridge_glambda(xx, perm.phe, fam, lbd)
      centers[i] = tmp$wstat
      coefs[i] = tmp$beta
    }

  }

  if (!is.null(oldseed))
    .GlobalEnv$.Random.seed <- oldseed
  else
    rm(".Random.seed", envir = .GlobalEnv)

  return(list('w_hat' = centers^2, 'beta' = coefs))
}
est_nullcenter = cmpfun(est_nullcenter)


#' Detect gene-gene interaction/epistasis by UM-MDR
#' @import compiler MASS glmnet
#' @param snp.all snp matrix, n by p.
#' @param phe phenotype, n by d matrix, d>=1.
#' @param K K-way interaction, default 2.
#' @param cova covariate.
#' @param classm classification rule to define H/L, 'mean', 'obs-ratio', and 'fpc' corresponding to
#' quantitative, binary and multivariate quantitative traits, respectively.
#' @param adj.main logical value, adjust marginal effect or not, default FALSE.
#' @param nperm small number of permutation time to estimate non-central parameters, default 5
#' @return a list including the elements:
#' \item{beta}{coefficients.}
#' \item{pvs}{p-values corrected by semiparamtric correction procudure.}
#' \item{alt.pvs}{alternative p-values, using pooled statstics to correct.}
#' \item{raw.pvs}{raw p-values.}
#' \item{best_comb}{best k-snps, which gives smallest corrected p-value.}
#' @examples
#'
#' snps <- matrix(rbinom(100 * 5, 1, 0.2), nrow = 100)  ## generate 5 snps
#' phe <- rnorm(100)  ## generate phenotype
#' umMDR(snps, phe, 2)
#' @rdname umMDR
#' @export
umMDR <- function(snp.all, phe, K = 2, cova = NULL, classm = 'mean',  adj.main = 'FALSE', nperm = 5){
  p = ncol(snp.all)
  snp.combs <- combn(p, K)   ## all SNP pairs
  ns = ncol(snp.combs)
  phe = as.matrix(phe)
  n = nrow(phe)
  d = ncol(phe)
  nc = ifelse(length(cova) == 0, 0, ncol(cova))
  dd = d + nc

  if(adj.main) dd = dd + K

  # save all coefs and pvs for S
  rpvs = pvs = coefs = rep(0.5, ns)
  fam = ifelse(classm == 'obs-ratio', 'binomial', 'gaussian')
  SS = phe
  if(classm == 'fpc') SS = fpc(phe)

  # select best model(i.e. snp combination)
  # use glm
  est_w = stats =  stats0 = NULL

  for(j in 1:ns){
    res = class_HL(snp.all[, snp.combs[, j]], SS, classm)
    labels = res$labels

    if(adj.main){
      xx = cbind(cova, snp.all[, snp.combs[, j]])

      # use ridge regression
      tmp1 = ridge_cv(cbind(xx, labels), phe - mean(phe), fam)
      coefs[j] = tmp1$beta
      vv = tmp1$vbeta
      stat = tmp1$beta^2/vv
      rpvs[j] = 2 * pnorm(-sqrt(stat))

      ## use the same lbd for ridge regression for permutations
      tmp2 = est_nullcenter(SS, xx, snp.all[, snp.combs[, j]], classm,
                            lbd=tmp1$lbd, nperm)

      lambda = mean(tmp2$w_hat) - 1
      if(lambda >= 0) pvs[j] = pchisq(stat, df = 1, ncp = lambda,
                                      lower.tail = FALSE )

      stat0 = abs(coefs[j] - mean(tmp2$beta))/sqrt(vv)
      if(lambda < 0) pvs[j] = 2 * pnorm(-stat0)

      est_w = c(est_w, tmp2$w_hat)
      stats = c(stats, stat)
      stats0 = c(stats0, stat0)

    }else{
      xx  = cbind(cova, labels)
      mod = glm(phe ~ xx, family = fam)
      res = coef(summary(mod))
      pp = nrow(res)
      coefs[j] = res[pp, 1]  # the coefficent vector
      rpvs[j] = res[pp, ncol(res)]
      vv = res[pp, 2]^2
      stat = res[pp, 1]^2/vv

      tmp2 = est_nullcenter(SS, cova, snp.all[, snp.combs[, j]],
                            classm, lbd = 0, nperm)

      lambda = mean(tmp2$w_hat) - 1
      if(lambda >= 0) pvs[j] = pchisq(stat, df = 1, ncp = lambda,
                                      lower.tail = FALSE )

      stat0 = abs(coefs[j] - mean(tmp2$beta))/sqrt(vv)
      if(lambda < 0) pvs[j] = 2 * pnorm(-stat0)
      est_w = c(est_w, tmp2$w_hat)
      stats = c(stats, stat)
      stats0 = c(stats0, stat0)
    }
  }

  # alternatively we can use pooled estimates of W

  # lbamda = mean(est_w) - 1
  # or, similar but a lit bit more robust
  lambda = (quantile(est_w, 0.75) + quantile(est_w, 0.25))/2 - 1

  if(lambda > 0 ) alt_pvs = pchisq(stats, df = 1, ncp = lambda, lower.tail = F)
  ## just in case, use alternative test
  if(lambda <= 0) alt_pvs = 2 * pnorm(-stats0)

  best_comb = snp.combs[, which.min(pvs)]
  return(list('beta' = coefs, 'pvs' = pvs, 'alt.pvs' = alt_pvs, 'raw.pvs' = rpvs,
              'best_comb' = best_comb))
}
umMDR <- cmpfun(umMDR)





