##=======================================================================##
##  This program is written by Wenbao yu for implementing
##  unified MDR, which has the following two step
## 1. assign high/low (S) for each cell
## 2. modeling:  use glm to test association between phenotype and S
## key idea: assume non-central chisquare null for testing association
##=======================================================================##

## list all functions ####
require(compiler)
require(glmnet)
require(MASS)

## calculate fist PC score
fpc <- function(pys){
  pys = scale(pys, center = TRUE, scale = FALSE)
  covm = cov(pys)
  eigens = eigen(covm)
  P = eigens$vectors
  AS = pys %*% P[, 1]  ## first PC scores
  return(AS)
}
fpc <- cmpfun(fpc)


## ridge regression for linear and logistic regression
ridge_lmglm <- function(X, Y, fam){

  ## use glmnet to select lambda
  mod = cv.glmnet(x = X, y = Y, standardize = FALSE,
                  family = fam, alpha = 0, nfolds = 10)
  lbd = mod$lambda.min/2
  lbds = mod$lambda/2   # all candidate lambda
  n = nrow(X)
  ff = cbind(rep(1, n), X)
  d = ncol(ff)

  # calculate covariance for beta
  if(fam == 'binomial'){
    beta = as.numeric(coef(mod))
    xx = ff %*% beta
    pp = exp(xx)/(1 + exp(xx))
    ww = diag(as.vector(pp * (1 - pp)))
    temp1 = t(ff) %*% ww %*% ff
    temp2 = solve(temp1 + 2 * lbd * diag(1, ncol(temp1)))
    varbeta = temp2 %*% temp1 %*% temp2
  }else{

    mod = lm.ridge(Y ~ X, lambda = lbd)
    beta = coef(mod)
    # alternative way of decideing lambda
    if(FALSE){
      mod = lm.ridge(Y ~ X, lambda = lbds)
      ind = which.min(mod$GCV)
      lbd = lbds[ind]
      beta = coef(mod)[ind, ]
    }
    temp = solve(t(ff) %*% ff + lbd * diag(ncol(ff)))
    #beta = temp%*% t(ff) %*% Y

    xx = ff %*% beta
    varbeta = temp %*% t(ff) %*% ff %*% temp
    sigma2 = crossprod(Y - xx, Y - xx)/(n- length(beta))
    varbeta = varbeta * as.vector(sigma2)
  }

  return(list('beta' = beta[-1], 'varbeta' = varbeta[2:d, 2:d], 'lbd' = lbd))
}
ridge_lmglm = cmpfun(ridge_lmglm)


## ridge regression given lambda
## note that only the result of the last column of X is returned
ridge_glambda <- function(X, Y, fam, lbd){

  n = nrow(X)
  ff = cbind(rep(1, n), X)
  p = ncol(X)
  # calculate covariance for beta
  if(fam == 'binomial'){
    ## use glmnet
    mod = glmnet(x = X, y = Y, standardize = FALSE,
                 family = fam, alpha = 0, lambda = 2 * lbd)

    beta = as.numeric(coef(mod))
    xx = ff %*% beta
    pp = exp(xx)/(1 + exp(xx))
    ww = diag(as.vector(pp * (1 - pp)))
    temp1 = t(ff) %*% ww %*% ff
    temp2 = solve(temp1 + 2 * lbd * diag(1, ncol(temp1)))
    varbeta = temp2 %*% temp1 %*% temp2
  }else{

    mod = lm.ridge(Y ~ X, lambda = lbd)
    beta = coef(mod)

    temp = solve(t(ff) %*% ff + lbd * diag(ncol(ff)))
    #beta = temp%*% t(ff) %*% Y

    xx = ff %*% beta
    varbeta = temp %*% t(ff) %*% ff %*% temp
    sigma2 = crossprod(Y - xx, Y - xx)/(n- length(beta))
    varbeta = varbeta * as.vector(sigma2)
  }
  center = beta[p+1]/sqrt(varbeta[p+1, p+1])
  return(center)
}
ridge_glambda = cmpfun(ridge_glambda)


## classification step, assign high/low for each cell and test
class_HL <- function(snp.dat, SS, classm = 'mean'){
  snp.dat = as.matrix(snp.dat)

  # remove missing values
  fids = which(complete.cases(snp.dat))
  snp.dat = as.matrix(snp.dat[fids, ])

  k = ncol(snp.dat)
  n = nrow(snp.dat)

  # split completed data into cells
  tlist = vector('list', k)
  for(i in 1:k) tlist[[i]] = snp.dat[, i]
  cells = split(data.frame(cbind(fids, snp.dat)), tlist)

  # delete NULL cells
  obs.cell = sapply(cells, function(x) nrow(x))
  cell.null = which(obs.cell == 0)
  if(length(cell.null) > 0 ) cells = cells[-cell.null]

  ncells = length(cells)
  high.ids  = NULL
  weights = rep(1, n)   ## weights defined as the mean of Y in each cell

  # classify each cell into H/L by various methods
  if(classm == 'mean' || classm == 'fpc'){
    # use mean to define H/L, corresponding to quatitative trait
    sbar = mean(SS)
    for(i in 1:ncells){
      temp.ids = cells[[i]][, 1]
      if(length(temp.ids) == 0) next
      mSS = mean(SS[temp.ids])
      weights[temp.ids] = (length(temp.ids))
      if (mSS >= sbar){
        high.ids = c(high.ids, temp.ids)
      }
    }
  }

  if(classm == 'obs-ratio'){
    # use the ratio of the number of cases to the number of obs,
    # corresponding to binary trait
    sbar = sum(SS)/n
    for(i in 1:ncells){
      temp.ids = cells[[i]][, 1]
      if(length(temp.ids) == 0) next
      temp.ratio = sum(SS[temp.ids])/length(temp.ids)
      weights[temp.ids] = 1/(max(temp.ratio, 1-temp.ratio))
      if (temp.ratio >= sbar){
        high.ids = c(high.ids, temp.ids)
      }
    }
  }

  low.ids = setdiff(fids, high.ids)

  # labels indicate high/low
  labels = rep(NA, n)
  labels[high.ids] = 1
  labels[low.ids] = 0

  # note that labels are NA, corresponding the obs that having NA for SNP
  return(list('labels' = labels, 'weights' = weights))
}
class_HL <- cmpfun(class_HL)


## estimat non-center parameter of the null distribution due to classification
est_nullcenter <- function(phe, cova, snp.pair, classm = 'mean', lbd = 0, nperm = 10){
  set.seed(1234)
  n = nrow(phe)
  center = rep(0, nperm)
  fam = ifelse(classm == 'obs-ratio', 'binomial', 'gaussian')
  for(i in 1:nperm){
    perm.phe = phe[sample(1:n, n)]
    res = class_HL(snp.pair, perm.phe, classm)
    labels = res$labels
    #meanH = mean(perm.phe[labels == 1])
    #meanL = mean(perm.phe[labels == 0])
    #center[i] = meanH - meanL
    xx = cbind(cova, labels)
    if(lbd == 0){
      sumstat = coef(summary(glm(perm.phe ~ xx, family = fam)))
      center[i] = sumstat[nrow(sumstat), 3]
    }else{
      ## use ridge regression
      center[i] = ridge_glambda(xx, perm.phe, fam, lbd)
    }

  }

  return(mean(center^2))
}
est_nullcenter = cmpfun(est_nullcenter)


#' Detect gene-gene interaction/epistasis by UM-MDR
#' @import compiler MASS glmnet
#' @param snp.all snp matrix, n by p.
#' @param K K-way interaction, default 2.
#' @param phe phenotype, n by d matrix, d>=1.
#' @param cova covariate.
#' @param classm classification rule to define H/L, 'mean', 'obs-ratio', and 'fpc' corresponding to
#' quantitative, binary and multivariate quantitative traits, respectively.
#' @param adj.main logical value, adjust marginal effect or not, default FALSE.
#' @param nperm small number of permutation time to estimate non-central parameters, default 5
#' @return a list including the elements:
#' \item{beta}{coefficients.}
#' \item{pv}{p-values corrected by semiparamtric correction procudure.}
#' \item{rpv}{raw p-values.}
#' @examples
#'
#' snps <- matrix(rbinom(100 * 5, 1, 0.2), nrow = 100)  ## generate 5 snps
#' phe <- rnorm(100)  ## generate phenotype
#' umMDR(snps, 2, phe)
#' @rdname umMDR
#' @export
umMDR <- function(snp.all, K=2, phe, cova = NULL, classm = 'mean',  adj.main = 'FALSE', nperm = 5){
  p = ncol(snp.all)
  snp.combs <- combn(p, K)   ## all SNP pairs
  ns = ncol(snp.combs)
  phe = as.matrix(phe)
  n = nrow(phe)
  d = ncol(phe)
  nc = ifelse(length(cova) == 0, 0, ncol(cova))
  dd = d + nc

  if(adj.main) dd = dd + K

  # save all coefs and pvs for S
  rpvs = pvs = coefs = rep(0, ns)

  jpv = rep(NA, ns)     # save pvalue for joint test beta1=beta2=beta3=0

  fam = 'gaussian'

  if(classm == 'obs-ratio') fam = 'binomial'

  SS = phe
  if(classm == 'fpc') SS = fpc(phe)

  # select best model(i.e. snp combination)
  # use glm

  for(j in 1:ns){
    res = class_HL(snp.all[, snp.combs[, j]], SS, classm)
    labels = res$labels

    if(adj.main){
      xx = cova
      for(i in 1:K) xx = cbind(xx, snp.all[, snp.combs[i, j]])

      # use ridge regression
      temp = ridge_lmglm(cbind(xx, labels), phe - mean(phe), fam)
      pp = length(temp$beta)
      coefs[j] = temp$beta[pp]

      stat = temp$beta[pp]^2/diag(temp$varbeta)[pp]
      rpvs[j] = pnorm(sqrt(stat), lower.tail = FALSE)

      null.center = est_nullcenter(SS, xx, snp.all[, snp.combs[, j]], classm,
                                   lbd=temp$lbd, nperm)

      #lambda = null.center
      lambda = max(0, null.center - 1)
      pvs[j] = pchisq(stat, df = 1, ncp = lambda, lower.tail = FALSE )

    }else{
      xx  = cbind(cova, labels)
      mod = glm(phe ~ xx, family = fam)
      res = coef(summary(mod))
      pp = nrow(res)
      coefs[j] = res[pp, 1]  # the coefficent vector
      rpvs[j] = res[pp, ncol(res)]
      stat = res[pp, 1]^2/res[pp, 2]^2

      null.center = est_nullcenter(SS, cova, snp.all[, snp.combs[, j]],
                                   classm, lbd = 0, nperm)

      lambda = max(null.center - 1, 0)

      pvs[j] = pchisq(stat, df = 1, ncp = lambda, lower.tail = FALSE )

    }
  }
  return(list('beta' = coefs, 'pv' = pvs, 'rpv' = rpvs))
}
umMDR <- cmpfun(umMDR)




